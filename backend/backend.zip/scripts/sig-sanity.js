// Exercises three cases against your WS listener:
// 1) unsigned non-bootstrap -> DROP (MISSING_SIG)
// 2) signed with WRONG key   -> DROP (INVALID_SIG)
// 3) signed with RIGHT key   -> PASS (handler logs SERVER_DELIVER)

require("dotenv").config();
const WebSocket = require("ws");
const { signPayload } = require("../network/crypto/signing");

const PORT = parseInt(process.env.MESH_WS_PORT || "7081", 10);
const URL  = `ws://127.0.0.1:${PORT}`;

const PEER_ID   = require("crypto").randomUUID();
const PEER_PUB  = "LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUlJQ0lqQU5CZ2txaGtpRzl3MEJBUUVGQUFPQ0FnOEFNSUlDQ2dLQ0FnRUFxT0orZ0ZGbDBPb0NzZlByUzJ1MApjc2VUNU5FV1JMbFhpa0I2dldFb1RWeFl3bjlIYndYeXFIaEVYbDBNL2VvaDVabk1YYVlYYlhBNjFrTWRDaSt3CllNaGxIbDBsQng3M3owVGdZb1p2SmNxdUtOaXhtbmRkNXVzQW4yMHNTRHppVGhLc082ZkhhWWF5QTQ3cTBlWUcKWGdLejBYOHFiWEFNL0UyblA5T1E0UUJSUkE2c1ZudTlYcVNSZGFoWmVUOXd1WG1FMnV2NExOMVFUaXdWREMrMgo2U0xZK3lUckdpQVZjdi9kZmJpaWhOeFpvaFprTXNucUpYUlk0RDBIR0VaeTNRQjlEQWlBSkY5V1JFRVFKYVZXCkR4V0d3eDcyVjNIdnMwd1BJbGlxS3ZGQUFGcDMvZ3pDdmJ6Qi9GQjArSDFoNi9tSTk3V0xMa1ZscWg1Rk0vcmEKK2dTc1pRTFpOOEhWNndtZW1wSURHQXBHTWdBem8wNEEzQUdONTVXcFlFa3hVbG5pVjJHMjY4QzBXZkd2Z0pJWApCd0dJQjVKMGlqa3U1QXhJblBGVnpmSGxLRjIvVHJRRWN5MjVCcXlVWnVBMUlJWHVySFVDVmcvUlFSMGRwVnZvCnExUXYwdGxtS1VZa2dramZ0V3QrYUdiZEpQbGFycXcxU2lWLzVCK3UvZDR6UmtWV3UxRU42VU8xNlRyRm9wM2kKdlc2Qmt0UHBkRzRseWx5NzZuakQwbVBMQ0d1WURvNmtXSWJqQ096MjVoU21mTkw1Z1MySm1HckpWS0U5QVNwTApyaDNIV2FpSktNa2gza0ZyYWdhZVNxNGd1ODloS2Fjb3pFU1NGb0w3ZXgzbHZZSVFkTk1tTXRDK2c0ejNsVC9pCndFTnVQTHdvbHVvaHo1OGpUY251RlZVQ0F3RUFBUT09Ci0tLS0tRU5EIFBVQkxJQyBLRVktLS0tLQo";
const PEER_PRIV = "LS0tLS1CRUdJTiBQUklWQVRFIEtFWS0tLS0tCk1JSUpRd0lCQURBTkJna3Foa2lHOXcwQkFRRUZBQVNDQ1Mwd2dna3BBZ0VBQW9JQ0FRQ280bjZBVVdYUTZnS3gKOCt0TGE3Unl4NVBrMFJaRXVWZUtRSHE5WVNoTlhGakNmMGR2QmZLb2VFUmVYUXo5NmlIbG1jeGRwaGR0Y0RyVwpReDBLTDdCZ3lHVWVYU1VISHZmUFJPQmlobThseXE0bzJMR2FkMTNtNndDZmJTeElQT0pPRXF3N3A4ZHBocklECmp1clI1Z1plQXJQUmZ5cHRjQXo4VGFjLzA1RGhBRkZFRHF4V2U3MWVwSkYxcUZsNVAzQzVlWVRhNi9nczNWQk8KTEJVTUw3YnBJdGo3Sk9zYUlCVnkvOTE5dUtLRTNGbWlGbVF5eWVvbGRGamdQUWNZUm5MZEFIME1DSUFrWDFaRQpRUkFscFZZUEZZYkRIdlpYY2UrelRBOGlXS29xOFVBQVduZitETUs5dk1IOFVIVDRmV0hyK1lqM3RZc3VSV1dxCkhrVXordHI2Qkt4bEF0azN3ZFhyQ1o2YWtnTVlDa1l5QURPalRnRGNBWTNubGFsZ1NURlNXZUpYWWJicndMUloKOGErQWtoY0hBWWdIa25TS09TN2tERWljOFZYTjhlVW9YYjlPdEFSekxia0dySlJtNERVZ2hlNnNkUUpXRDlGQgpIUjJsVytpclZDL1MyV1lwUmlTQ1NOKzFhMzVvWnQwaytWcXVyRFZLSlgva0g2Nzkzak5HUlZhN1VRM3BRN1hwCk9zV2luZUs5Ym9HUzArbDBiaVhLWEx2cWVNUFNZOHNJYTVnT2pxUllodU1JN1BibUZLWjgwdm1CTFltWWFzbFUKb1QwQktrdXVIY2RacUlrb3lTSGVRV3RxQnA1S3JpQzd6MkVwcHlqTVJKSVdndnQ3SGVXOWdoQjAweVl5MEw2RApqUGVWUCtMQVEyNDh2Q2lXNmlIUG55Tk55ZTRWVlFJREFRQUJBb0lDQUVRa3E0MUVDclNLajQ3VkVFWXN6YkVZCmRVUzQxdWJnOEFFQk5tVXVqQy8yeUh1bUZxRW1BYnpYVmlMTEllQmNOZFFxUStzdmhybHFOTnRhVmgvVGtUUGoKOStVU0NVdy93eGEzUUdDUXhNMDNaQ0ZvR2ZWdEg0NzZtSlE3WFVoQ2hMK2l5aXNCN2pUV25BSlNpczRwcGIwTwpFeGMvVzlPdmlCWFBrV0h3RUQreFBKa2M0STIrdlBDd3IxNk5rSmliTC9VdW9wd2c1VkRZOWJ1dERzc05mNXkvCktsVGZseHRDQWRXV2h2emc0SGFDWUlwRnhhVTJrb3NOVUlVZUtyd3hSTXlHazI0bENldGpLbkE4M25LS0xWakYKdzB2OHRNSWczMnAxa0krM3ZlVzQxUzJ2VTBaSFNOWjlFTHFwamlEcm1uUzRDWHVGbllTTWpOSmhCMlJMWGtvbAp4SFQ3WlE0WURkK0czdU9ReWJqbUdHWXI2UGJRYnVwdXdoeVIzeFNqbmU3cVhRRm8vbzlOOUozMTRaME54T2hzCmJNc2lXVnRqN3d3dHNPQ1B3dHFuSDdnVlNKdnoySHp5MlJxZzZIcm43N01qbWcrWk5HV04xbGlQTXZTQzB6VDgKUDVXakxaSFdhSTB6RnVELzcwejcreUE1S25JeFM0amIzdWora1l4cld6NzR3Zlg1b2F6OTF0elVycEhKRG5McQozUHF2YlJDYlR1enV1SHdTNENoRVF4UFJWZTJFY3d0bTdOVkNIandNMkxsMGRWVXVvTXo3R2hia1MxSTZLMG9vClZxakVJSS9pTFdtdEVSTjdOVVNJcmZlQzZxSHp1V0FKQlVtcGU2aUlSRDYyVEVOblhTTFVabDNRNEpmTnFPS3EKUjRLbTE1Mkk3MVFDZ2ptT3FCZmJBb0lCQVFEa3RxcFJCdmphbElXcXc4cDhncDBzcjNtRk12TnFHamJnNmlBbAp4MEs3VVIvaXpWdG43VFpkdHZ4V3B3VEo4eTB0ZkZxbXhsTllZVlkzek92NFFYUHlhaEFVa2pCMDNqdjl0TmY4Cm83NGIvWHRhalVKSTJhdVFrdDYwWWQwL3JMcVp0WUJhRmhFS3YxUHBPMGNJY3dMQzB2Uzh4NWl4SzJDUE5xTkIKOCtneldXK3dJUWZBWE1KK3hpMUtIdFNuUVg2Mi9RamZmcGpNMWJRdWNCcW1PbTR1bU5wQUpsZ0R6OXYzNnRkeApYdVFuWlVUcmF3aUVhNXZsK0RUSURyT003bTBpQk1xSkZWVnZPcWU0MElhK29xcGw2eER4WWhkK2txNjQ1dzhRCkFxR0VWUXVSRGRxQTB5V2sreW9sNUhsdXNkRFVVQ0xyTkMvZDcwK1l0YzZQVXpWdkFvSUJBUUM5Q0l2NGVsS2sKVWpzQkNDNzhQSWxvZ2l1S2pjNGJEbXU0NDBzRVNyUkg2UXpUekQrR2FPdHZod0xjVDhBL1FYTGdpK29jNnhPYwp1Z1JDckFhenJwTnFrdER5Unc1Z0JaRitZamdiVmR5UGkvaVJpWnUvRlRiZW1rbU5lNGJYem4wVVZONFVuY29kCnVCcFZJTUpCWHZ2VmpxQ3JUSy9XdFdCVjJNQm5jVitjcHZFaURNU1FiZHpCL0RPZkJ1dy96bkRxTGZPT1pEN1gKcVdrN25qYTZaNDRPQmZZbXZkN0Y0UGkvTXJRZWNXNlB3TGxocTR3Q0xZWDhRWG8rK1lialFGcFR2Tzd5bU53MwplRUtpbE9QVWkwYUtIM0thSzNXdEN6TXhmdmJVT3JSNVVLZkZhRGU1V1hRZEcrVUNudFZDYXlPbTRPaGxaQ01lCnk3dFdZc1VRYUtkN0FvSUJBUURJTFZoRU11WDc2YUpVSTZsRjhNdkFJSlVyajd5Y1VQVlhSWk45ZlRsYTJWWWYKRzcyMDZGbDlESHN2SEYrRW9lSVl2WTVhQ1p0STcyaVd6alI1eEUvSERDMm0wNHkxdlF5a3NYT1pHM2Q0NkJMZQozbVAxZnc0NksxSGdid2RHZzllT1VOMVYrNXBPM2NhRGkrNVA1dG16eXcrSmF1aXBxRjJLK3pkSXNrRzVMNzRoCldjZC9CYkQxWkY2ZlVQeXVweFJROUlhZmxoNEdxY1JhSUtReWVWR1dWeEl1czJDMWRXZ0JSUG5yc0RIZ2lUSVoKR2tVS0lXVUJrb3dmelQ0NVN6VVpZVGdqWXhpemtaTGFueWhRRWU4eDVOdWZhVXRHN1BzZnVwdmtWMmttZVlqMgpIRG55SnR2NzJoaTVzWTdXNDZyektIQm5pL1daT2F0ZzdUOHRFcGJoQW9JQkFDT1RialJQWVNwSHg0OEVLVU9UCmFSRGdIcTJ1em5GTkgzem1XZ0h1eFVzYlV5eXhMZXR2NTQ5UHkzd0hEbGxaU2ZOMG9aVGJzUTgzK3dGSk91R3EKSTFoVlZUbWpvZEwwZVZOZHpNMW9OV0JXcVd0S2lLTkhyTkhzRzVlaS9kZXpwdHFpdGtFUENURGFxeW9HUmtqagpSV1lGdDd0RmJYcHRIRHBMMXJvaEhpdHZSOFp1dkxlcDFYZzByTXByRlI5VkRPOGx3c2F6bXhnZmJBeXFWQVowCjRzbEUyZlNrbXo2R2Zvb05VdFMvNkZ6cG1ub0ZQUTVUM3ZtQW9TOGs2dnZ0NnBJRDVyeUZoRHgwUjZZdGUwdFAKQXZHUHhaTzZSaVZSREV0dVo2bTllcVd5UmtEaXdrb0J5ZGFJbjJzRTFZSHdnLzh1S002Y0wvZmx3OVlZTkpwSAo5KzBDZ2dFQkFLZDM1anliQ2VOaGdycXg5aUsyenBSTk1Bc1BsVm1rTm8yeG9VZXpDaFBNaEFNVWlzTjdoaVBGCm56eWFubDYrVmdOZDk3b29Nc1drVTBCVXF3ckhXMTFBNEpMSEpzNnBUYWwvME81b0hDNlgzcnE4YUhlbHdUVHUKZjlSWlZOQmkxdG1TUWZuS2pYa1lET1c4eGx0cHhpdDB0ekdKTDB2THpYNFd0UDltMmpDVjdXb0FwWGhvSktxSwpvUmNoM0hKYjBXYkZEMlR3U3Z4dUZyQ2RTSlp3Y05xTzVDY3ZSU2dYT3ZJVUl5dGQva3hQNVdtR3A3MHVzTG1LCkp6WjdjNnNhQlVzRlpCL1B0S2gzblJvZXlnOU9FNFoxRW5mU3oyVnRIdk1UbFF0UDVaY3hhckczUmx5a3Y5M04KMEVUdFE5d2R5bXMvN0ZPS2xBWHpIM2tLVkgxVnVLaz0KLS0tLS1FTkQgUFJJVkFURSBLRVktLS0tLQo";

// We'll use your *server's* private key to craft a WRONG signature for test #2
const SERVER_PRIV = process.env.SERVER_PRIVATE_KEY_B64URL;

function send(ws, frame) { ws.send(JSON.stringify(frame)); }
const now = () => Date.now();

function unsignedDeliver() {
  return {
    type: "SERVER_DELIVER",
    from: PEER_ID,
    to: "*",
    ts: now(),
    payload: { user_id: "u1", ciphertext: "<opaque>", sender: "u2" },
    // no sig on purpose
  };
}
async function signedDeliverWith(privB64Url) {
  const env = unsignedDeliver();
  env.sig = await signPayload(env.payload, privB64Url);
  return env;
}

(async () => {
  if (!PEER_PUB || !PEER_PRIV) {
    console.error("Missing DUMMY peer keys in env. Re-run step B exports.");
    process.exit(2);
  }

  const ws = new WebSocket(URL);
  ws.on("open", async () => {
    console.log("[sig] connected; sending SERVER_HELLO_LINK (unsigned, allowed) …");
    send(ws, {
      type: "SERVER_HELLO_LINK",
      from: PEER_ID,
      to: "*",
      ts: now(),
      payload: { url: "ws://dummy", pubkey_b64url: PEER_PUB }, // teaches server our pubkey
    });

    // 1) UNSIGNED non-bootstrap -> expect DROP MISSING_SIG
    setTimeout(() => {
      console.log("[sig] sending UNSIGNED SERVER_DELIVER (should DROP: MISSING_SIG)");
      send(ws, unsignedDeliver());
    }, 200);

    // 2) BAD SIG (signed with server's key, not peer's) -> expect DROP INVALID_SIG
    setTimeout(async () => {
      console.log("[sig] sending BAD-SIG SERVER_DELIVER (should DROP: INVALID_SIG)");
      const bad = await signedDeliverWith(SERVER_PRIV);
      send(ws, bad);
    }, 500);

    // 3) GOOD SIG (signed with peer's own private key) -> expect PASS (handler logs)
    setTimeout(async () => {
      console.log("[sig] sending GOOD-SIG SERVER_DELIVER (should PASS)");
      const good = await signedDeliverWith(PEER_PRIV);
      send(ws, good);
    }, 900);

    // finish shortly after
    setTimeout(() => process.exit(0), 1400);
  });

  ws.on("error", (e) => {
    console.error("[sig] ws error", e.message);
    process.exit(2);
  });
})();
